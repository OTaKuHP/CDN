#!/bin/bash
if [[ -n $USE_SA && -n $RCLONE_DESTINATION && -n $SA_INIT_FILE && -n $TEAM_DRIVE_ID ]]; then
	echo "Usage of Service Accounts Detected. Generating Config"
	echo -e "[DRIVE]\ntype = drive\nscope = drive\nservice_account_file = /app/accounts/$SA_INIT_FILE\nservice_account_file_path = /app/accounts/\nteam_drive = $TEAM_DRIVE_ID" >> rclone.conf
	echo "on-download-stop=./delete.sh" >> aria2c.conf
	echo "on-download-complete=./on-complete.sh" >> aria2c.conf
	chmod +x delete.sh
	chmod +x on-complete.sh
elif [[ -n $RCLONE_CONFIG_BASE64 && -n $RCLONE_DESTINATION ]]; then
	echo "Rclone config detected"
	echo "[DRIVE]" > rclone.conf
	echo "$(echo $RCLONE_CONFIG_BASE64|base64 -d)" >> rclone.conf
	echo "on-download-stop=./delete.sh" >> aria2c.conf
	echo "on-download-complete=./on-complete.sh" >> aria2c.conf
	chmod +x delete.sh
	chmod +x on-complete.sh
else
	echo "No Service Accounts Nor Rclone Config Provided."
	echo "Please Dont forgot to Provide RCLONE_DESTINATION and Destination TEAM_DRIVE_ID while Using Service Accounts."
fi
echo "rpc-secret=$ARIA2C_SECRET" >> aria2c.conf
aria2c --conf-path=aria2c.conf&
yarn start
